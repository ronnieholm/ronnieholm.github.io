﻿using System;

namespace Filosofparken.Helpers {
    public static class Utility {
        public static string FormatMac(string mac) {
            return String.Format("{0}:{1}:{2}:{3}:{4}:{5}", mac.Substring(0, 2),
                                                            mac.Substring(2, 2),
                                                            mac.Substring(4, 2),
                                                            mac.Substring(6, 2),
                                                            mac.Substring(8, 2),
                                                            mac.Substring(10, 2));
        }
    }
}
