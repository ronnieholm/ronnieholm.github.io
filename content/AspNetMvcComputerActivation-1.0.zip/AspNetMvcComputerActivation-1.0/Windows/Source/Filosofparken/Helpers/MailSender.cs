﻿using System.Configuration;
using System.Net.Mail;

namespace Filosofparken.Helpers {
    public class MailSender {
        public static void Send(string recipients, string subject, string body) {
            var smtpClient = new SmtpClient();
            smtpClient.Host = ConfigurationManager.AppSettings["SmtpServer"];
            smtpClient.Send(ConfigurationManager.AppSettings["SenderAddress"], 
                            recipients, 
                            subject, 
                            body);
        }
    }
}
