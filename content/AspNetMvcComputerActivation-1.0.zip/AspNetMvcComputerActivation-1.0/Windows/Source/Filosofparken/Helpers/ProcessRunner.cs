﻿using System.Diagnostics;

namespace Filosofparken.Helpers {
    public class ProcessRunner {
        public string Output { get; private set; }
        public string Error { get; private set; }

        public void Run(string executable, string arguments)
        {
            var p = new Process();
            p.StartInfo.FileName = executable;
            p.StartInfo.Arguments = arguments;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.RedirectStandardError = true;
            p.StartInfo.UseShellExecute = false;

            p.Start();
            p.WaitForExit();
            Output = p.StandardOutput.ReadToEnd();
            Error = p.StandardError.ReadToEnd();
        }
    }
}
