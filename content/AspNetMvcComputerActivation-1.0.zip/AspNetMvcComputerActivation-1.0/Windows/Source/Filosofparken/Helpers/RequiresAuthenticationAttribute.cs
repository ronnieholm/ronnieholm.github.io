﻿using System.Web.Security;
using System.Web.Mvc;

namespace Filosofparken.Helpers {
    /// <summary>
    /// Checks the User’s authentication using FormsAuthentication
    /// and redirects to the Login Url for the application on fail
    /// </summary>
    public class RequiresAuthenticationAttribute : ActionFilterAttribute {
        public override void OnActionExecuting(FilterExecutingContext filterContext) {
            // redirect if not authenticated
            if (!filterContext.HttpContext.User.Identity.IsAuthenticated) {
                // use the current url for the redirect
                string redirectOnSuccess = filterContext.HttpContext.Request.Url.AbsolutePath;

                // send them off to the login page
                string redirectUrl = string.Format("?ReturnUrl={0}", redirectOnSuccess);
                string loginUrl = FormsAuthentication.LoginUrl + redirectUrl;
                filterContext.HttpContext.Response.Redirect(loginUrl, true);
            }
        }
    }
}
