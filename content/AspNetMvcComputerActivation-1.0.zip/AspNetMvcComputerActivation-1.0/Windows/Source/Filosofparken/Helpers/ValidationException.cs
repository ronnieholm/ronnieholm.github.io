﻿using System;
using System.Collections.Generic;

namespace Filosofparken.Helpers {
    public class ValidationException : Exception {
        public IList<string> Errors { get; set; } 

        public ValidationException(string message) 
            : base(message) {
            Errors = new List<string>();
        }

        public ValidationException(string message, Exception innerException)
            : base(message, innerException) {
        }
    }
}
