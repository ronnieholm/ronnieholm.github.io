﻿using System;
using System.Collections.Generic;

namespace Filosofparken.Helpers {
    public struct ArpEntry {
        public string Ip;
        public string Mac;
    }

    public class ArpCache {
        public static IList<ArpEntry> GetAllEntries() {
            // input>  arp -a
            // output> 192.168.1.4           00-11-95-2a-ed-38     dynamic
            var pr = new ProcessRunner();
            pr.Run("arp", "-a");
            string[] lines = pr.Output.Split(new [] { "\r\n" }, StringSplitOptions.None);
            var mappings = new List<ArpEntry>();
            foreach (string line in lines) {
                if (line.Contains("dynamic")) {
                    string l = line.Trim();
                    string ip = l.Substring(0, l.IndexOf(' '));
                    string mac = l.Substring(l.IndexOf(' '), l.IndexOf("dynamic") - l.IndexOf(' ')).Trim().Replace("-", "");
                    mappings.Add(new ArpEntry { Ip = ip, Mac = mac });
                }
            }
            return mappings;
        }
    }
}
