﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Text.RegularExpressions;
using System.Web.Security;
using Filosofparken.Helpers;
using Filosofparken.Models;

namespace Filosofparken.Controllers {
    public class UserControllerViewData {
        public UserControllerViewData() {
            ErrorMessages = new List<string>();
        }

        public IEnumerable<User> Users { get; set; }
        public User User { get; set; }
        public IList<string> ErrorMessages { get; set; }
        public ArpEntry ArpEntry { get; set; }
        public bool ActivatedMac { get; set; }
    }

    public class UserController : Controller, IDisposable {              
        private readonly FilosofparkenDataContext _db = new FilosofparkenDataContext();
        private readonly UserControllerViewData _viewData = new UserControllerViewData();

        // visited by wget through a cronjob
        public void CleanUpDatabase() {
            // scan for computers without associated macs and deactivate
            var users = from u in _db.Users
                        from m in u.Macs.DefaultIfEmpty()
                        where m.Mac1 == null && u.Active && u.Created < DateTime.Now.AddHours(-24)
                        select u;

            foreach (User u in users) {
                DeactivateAccount(u.UserId);
                MailSender.Send(u.Email, "Filosofparken: Your account has been deactivated",
                                string.Format("Dear {0},\n\nYour account has been deactivated because no computers were associated with the account. The most likely reason is that after you created the account, you forgot to (1) login to http://www.filosofparken.dk, (2) navigate to the 'Edit profile' menu item, (3) change the activation status for your computer, and (4) hitting the 'Save' button.\n\nTo gain Internet access you'll have to create a new account.\n\nRegards,\n\nThe IT group", u.Username));
            }

            // deactivate non-validated accounts
            users = from u in _db.Users
                    where u.Active && u.Validation == DateTime.Parse("1/1/1900") &&
                          u.Created < DateTime.Now.AddHours(-24) &&
                          u.Created >= new DateTime(2008, 6, 1)
                    select u;

            foreach (User u in users) {
                DeactivateAccount(u.UserId);
                MailSender.Send(u.Email, "Filosofparken: Your account has been deactivated",
                                string.Format("Dear {0},\n\nYour account has been deactivated because you haven't validated your email address. Validation is done by following the validation link in the email received upon account creation or by requesting a new valdation email using the 'Retrieve lost account info' menu item on http://www.filosofparken.dk.\n\nTo re-gain Internet access you'll have to create a new account.\n\nRegards,\n\nThe IT group", u.Username));
            }
        }

        private void DeactivateAccount(int id) {
            User user = _db.Users.Single(u => u.UserId == id && u.Active);

            foreach (Mac m in user.Macs) {
                m.Active = false;
                m.Modified = DateTime.Now;
            }

            user.Active = false;
            user.Modified = DateTime.Now;
            _db.SubmitChanges();
        }

        [RequiresAuthentication]
        public void DeactivateUser(int id) {
            _viewData.User = _db.Users.Single(u => u.UserId == id);
            RenderView("DeactivateUser", _viewData);
        }

        [RequiresAuthentication]
        public void ProcessDeactivateUser(int id) {           
            _viewData.User = _db.Users.Single(u => u.UserId == id && u.Active);

            // authenticate
            if (_viewData.User.Username != HttpContext.User.Identity.Name)
                throw new UnauthorizedAccessException(string.Format("You are not authorized to delete other peoples accounts. Logged in as user '{0}' but attempting to delete user '{1}'s account", HttpContext.User.Identity.Name, _viewData.User.Username));

            DeactivateAccount(_viewData.User.UserId);
            Logout();
        }

        public void RetrieveLostAccountInfo() {
            RenderView("RetrieveLostAccountInfo", _viewData);
        }

        public void ProcessRetrieveLostAccountInfo() {
            _viewData.User = new User();
            BindingHelperExtensions.UpdateFrom(_viewData.User, Request.Form);
            
            // email field type doesn't support querying with LINQ, so iterate manually
            bool foundUser = false;
            foreach (User u in _db.Users) {                    
                if (u.Email.ToLower() == _viewData.User.Email.ToLower() && u.Active) {
                    // multiple accounts with same email means multiple emails                    
                    MailSender.Send(_viewData.User.Email, "Filosofparken: Lost account info",
                                    string.Format("Your username at Filosofparken is '{0}' and your password is '{1}'.\n\nIf you haven't already validated your email address, you can do so by following the link below:\n\nhttp://{2}{3}/User.mvc/Validate/{4}\n(If clicking the link doesn't work, try copying and pasting it into your browser).\n\nRegards,\n\nThe IT group", u.Username, u.Password, Request.Url.Host, Request.Url.Port != 80 ? ":" + Request.Url.Port : "", u.ValidationKey));                 
                    foundUser = true;
                }
            }

            if (foundUser) {
                RenderView("RetrieveLostAccountInfoSucceeded", _viewData);
            } else {
                _viewData.ErrorMessages.Add(string.Format("No user exists with email address '{0}'", _viewData.User.Email));
                RenderView("RetrieveLostAccountInfo", _viewData);
            }
        }

        public void Create() {
            // TODO: If already logged in => redirect to front page
            _viewData.User = new User() { Infomails = true };
            RenderView("Create", _viewData);
        }

        public void New() {
            // TODO: If already logged in => redirect to front page
            // fill in values for new user not provided through the page
            _viewData.User = new User
            {
                Created = DateTime.Now,
                Modified = DateTime.Now,
                LastLogin = DateTime.Parse("1/1/1900"),
                Validation = DateTime.Parse("1/1/1900"),
                ValidationKey = Guid.NewGuid().ToString(),
                Active = true
            };
            
            try {
                BindingHelperExtensions.UpdateFrom(_viewData.User, Request.Form);

                // apply custom validation
                ValidationException exception = ValidateUser(_viewData.User);
                if (exception.Errors.Count > 0)
                    throw exception;

                _db.Users.InsertOnSubmit(_viewData.User);
                _db.SubmitChanges();

                // send of validation mail to account
                MailSender.Send(_viewData.User.Email, "Filosofparken: Registration confirmation",
                                string.Format("Hey {0},\n\nYou recently registered for a Filosofparken account using this email address. To complete the registration, follow the link below:\n\nhttp://{1}{2}/User.mvc/Validate/{3}\n(If clicking the link doesn't work, try copying and pasting it into your browser.)\n\nRemember to login and activate your computer after you've created the account.\n\nIf you did not register for a Filosofparken account, please disregard this message.\n\nRegards,\n\nThe IT group", _viewData.User.Username, Request.Url.Host, Request.Url.Port != 80 ? ":" + Request.Url.Port : "", _viewData.User.ValidationKey));
                _viewData.User = _db.Users.Single(u => u.Username == _viewData.User.Username && u.Active);
                RenderView("CreateSucceeded", _viewData);
            } catch (PopulateTypeException e) {
                foreach (ExceptionInfo ei in e.LoadExceptions)
                    _viewData.ErrorMessages.Add(ei.ErrorMessage);
                RenderView("Create", _viewData);
            } catch (ValidationException e) {
                foreach (string s in e.Errors)
                    _viewData.ErrorMessages.Add(s);
                RenderView("Create", _viewData);
            }
        }

        [RequiresAuthentication]
        public void Edit(int id) {
            SetupArpEntryAndActivatedMacWithViewData(id, _viewData);
            _viewData.User = _db.Users.Single(u => u.UserId == id);

            // authenticate
            if (_viewData.User.Username != HttpContext.User.Identity.Name)
                throw new UnauthorizedAccessException(string.Format("You are not authorized to view this page. Logged in as user '{0}' but attempting to edit user '{1}'s profile", HttpContext.User.Identity.Name, _viewData.User.Username));

            RenderView("Edit", _viewData);
        }

        [RequiresAuthentication]
        public void Update(int id) {
            try {
                SetupArpEntryAndActivatedMacWithViewData(id, _viewData);
                _viewData.User = _db.Users.Single(u => u.UserId == id);

                // authenticate
                if (_viewData.User.Username != HttpContext.User.Identity.Name)
                    throw new UnauthorizedAccessException(string.Format("You are not authorized to view this page. Logged in as user '{0}' but attempting to edit user '{1}'s profile", HttpContext.User.Identity.Name, _viewData.User.Username));

                string oldEmail = _viewData.User.Email;
                BindingHelperExtensions.UpdateFrom(_viewData.User, Request.Form);
                _viewData.User.Modified = DateTime.Now;

                // changing email address equated to invalidating the account
                if (oldEmail != _viewData.User.Email) {
                    _viewData.User.Validation = DateTime.Parse("1/1/1900");
                    _viewData.User.ValidationKey = Guid.NewGuid().ToString();
                }

                // apply custom validation 
                ValidationException exception = ValidateUser(_viewData.User);
                if (exception.Errors.Count > 0)
                    throw exception;
                ValidationException updateException = UpdateMacsTable(id);
                if (updateException.Errors.Count > 0)
                    throw updateException;

                _db.SubmitChanges();
                RedirectToAction("Index", "Home");
            } catch (PopulateTypeException e) {
                foreach (ExceptionInfo ei in e.LoadExceptions)
                    _viewData.ErrorMessages.Add(ei.ErrorMessage);
                RenderView("Edit", _viewData);
            } catch (ValidationException e) {
                foreach (string s in e.Errors)
                    _viewData.ErrorMessages.Add(s);
                RenderView("Edit", _viewData);
            }
        }

        public void Validate() {
            // file path is of the form "/User.mvc/Validate/ede2d1ae-03ed-4122-98e1-d8becf043a65"
            string filePath = Request.FilePath;
            string guid = filePath.Substring(filePath.LastIndexOf('/') + 1, filePath.Length - filePath.LastIndexOf('/') - 1);
            int count = (from u in _db.Users where u.ValidationKey == guid && u.Active select u.UserId).Count();

            if (count == 1) {
                User user = _db.Users.Single(u => u.ValidationKey == guid && u.Active);
                user.Validation = DateTime.Now;
                _db.SubmitChanges();
            } else {
                _viewData.ErrorMessages.Add(string.Format("Validation key '{0}' is unknown. Does the Url in the browser's address bar match the one in the validation mail? Or did you change you email address? In that case, make sure to Retrieve lost account info on the left menu.", guid));
            }
            RenderView("Validate", _viewData);
        }

        public void Login() {
            RenderView("Login", _viewData);
        }

        public void Authenticate() {
            string username = Request["User.Username"];
            string password = Request["User.Password"];
            int count = (from u in _db.Users
                         where u.Username == username && 
                               u.Password == password &&
                               u.Active
                         select u.UserId).Count();
            if (count != 1) {
                _viewData.ErrorMessages.Add("Username or password is incorrect");
                RenderView("Login", _viewData);
            } else {
                // TODO: Doesn't redirect to the original url, but the front page because 
                // RedirectFromLoginPage doesn't read the ReturnUrl correctly from the url!
                User user = _db.Users.Single(u => u.Username == username && u.Active);
                user.LastLogin = DateTime.Now;
                _db.SubmitChanges();
                FormsAuthentication.RedirectFromLoginPage(user.Username, false);
            }
        }

        public void Logout() {
            FormsAuthentication.SignOut();
            RedirectToAction("Index", "Home");
        }

        public void ValidatedMacs() {
            var macs = from m in _db.Macs
                       where m.Active
                       select m.Mac1;
            ControllerContext.HttpContext.Response.Write("#ValidatedToken#" + Environment.NewLine);
            foreach (string m in macs) {
                ControllerContext.HttpContext.Response.Write(Utility.FormatMac(m) + Environment.NewLine);
            }
        }

        private ValidationException UpdateMacsTable(int id) {
            var ex = new ValidationException("Error(s) during validation of input. See the Errors collection of the exception for details.");                     

            foreach (string key in Request.Form.AllKeys) {
                if (key.StartsWith("mac_")) {
                    string macWithOutPrefix = key.Replace("mac_", "");
                    bool activated = Boolean.Parse(Request[key]);
                    int count = (from m in _db.Macs
                                 where m.Mac1 == macWithOutPrefix && m.Active && m.UserId == id
                                 select m.MacId).Count();

                    if (count == 1) {
                        // Mac exists in Macs table
                        Mac mac = _db.Macs.Single(m => m.Mac1 == macWithOutPrefix && m.Active && m.UserId == id);
                        if (activated) {
                            mac.Active = activated;
                        } else {
                            mac.Active = false;
                            mac.Modified = DateTime.Now;
                        }
                    } else if (count == 0) {
                        // Mac doesn't exist in Macs table. However, only attach the mac to the user's
                        // account if the user set the activation status to "Activated", and make sure the
                        // mac isn't already taken by another user.
                        if (activated) {
                            int total = (from m in _db.Macs
                                         where m.Mac1 == macWithOutPrefix && m.Active
                                         select m.MacId).Count();

                            if (total > 0) {
                                // mac is taken by another user -- log and abort updating this mac's activation status
                                Mac ownerMac = _db.Macs.Single(m => m.Mac1 == macWithOutPrefix && m.Active);
                                User user = _db.Users.Single(u => u.UserId == ownerMac.UserId);
                                ex.Errors.Add(string.Format("Activation status of '{0}' cannot be changed. '{0}' is owned by user '{1}'", Utility.FormatMac(macWithOutPrefix), user.Username));
                                continue;
                            }

                            var unknown = new Mac
                            {
                                Active = true,
                                Created = DateTime.Now,
                                Modified = DateTime.Now,
                                Mac1 = macWithOutPrefix,
                                UserId = id,
                            };
                            _db.Macs.InsertOnSubmit(unknown);
                        }
                    } else {
                        throw new InvalidOperationException(string.Format("Macs table contains more than one entry for mac '{0}'. Should never happen", macWithOutPrefix));
                    }
                }
            }
            return ex;
        }

        [NonAction]
        public void Dispose() {
            if (_db != null)
                _db.Dispose();
        }

        private ValidationException ValidateUser(User user) {
            var ex = new ValidationException("Error(s) during validation of input. See the Errors collection of the exception for details.");                     
            // At first sight, strings never seem to be null. Rather they're empty. But this only holds true for
            // IE and Firefox. During actual use, NullRerenceExceptions were encountered from users of Safari.
            // So, some browsers happily post null as a form value if no value is entered.
            if (string.IsNullOrEmpty(user.Username))
                ex.Errors.Add("Username cannot be empty");
            if ((from u in _db.Users 
                 where u.Username == user.Username && u.Active && u.UserId != user.UserId
                 select u.UserId).Count() > 0)
                ex.Errors.Add("Username already taken");
            if (string.IsNullOrEmpty(user.Password))
                ex.Errors.Add("Password cannot be empty");
            if (string.IsNullOrEmpty(user.RealName))
                ex.Errors.Add("Real name cannot be empty");
            if (string.IsNullOrEmpty(user.Apartment))
                ex.Errors.Add("Apartment cannot be empty");
            if (string.IsNullOrEmpty(user.Email))
                ex.Errors.Add("Email cannot be empty");
            else {
                //try {                
                //MailAddress address = new MailAddress(user.Email);
                //} catch (FormatException e) {
                //    ex.Errors.Add(e.Message);
                //}
                // Regular expression from http://regexlib.com/REDetails.aspx?regexp_id=711 (RFC 2822 validation)
                bool validEmail = Regex.IsMatch(user.Email, @"^((?>[a-zA-Z\d!#$%&'*+\-/=?^_`{|}~]+\x20*|\""((?=[\x01-\x7f])[^\""\\]|\\[\x01-\x7f])*\""\x20*)*(?<angle><))?((?!\.)(?>\.?[a-zA-Z\d!#$%&'*+\-/=?^_`{|}~]+)+|\""((?=[\x01-\x7f])[^\""\\]|\\[\x01-\x7f])*\"")@(((?!-)[a-zA-Z\d\-]+(?<!-)\.)+[a-zA-Z]{2,}|\[(((?(?<!\[)\.)(25[0-5]|2[0-4]\d|[01]?\d?\d)){4}|[a-zA-Z\d\-]*[a-zA-Z\d]:((?=[\x01-\x7f])[^\\\[\]]|\\[\x01-\x7f])+)\])(?(angle)>)$");
                if (!validEmail)
                    ex.Errors.Add("Email doesn't appear to be valid");            
            }
            if (user.Block == "None")
                ex.Errors.Add("Block must contain a selection");
            if (user.Apartment == "None")
                ex.Errors.Add("Apartment must contain a selection");
            if (!string.IsNullOrEmpty(user.Phone)) {
                if (user.Phone.Length != 8)
                    ex.Errors.Add("Phone number must be an eight digit number");
                int result;
                if (!Int32.TryParse(user.Phone, out result))
                    ex.Errors.Add("Phone number may only consist of digits");
            }
            return ex;
        }

        private void SetupArpEntryAndActivatedMacWithViewData(int? userId, UserControllerViewData viewData) {
            IList<ArpEntry> entries = ArpCache.GetAllEntries();
            var macs = from m in entries
                       where m.Ip == Request.UserHostAddress
                       select m.Mac;

            if (macs.Count() == 0) {
                // are we in development mode?
                if (Request.Url.DnsSafeHost == "localhost") {
                    viewData.ArpEntry = new ArpEntry { Mac = "1234567890ab" };
                    viewData.ActivatedMac = false;
                }
                // if not in dev mode and mac not in arp cache? Is the user accessing
                // this page from a non-LAN location?
            } else {
                viewData.ArpEntry = entries.Single(e => e.Ip == Request.UserHostAddress);
            }

            // for a user about to be created, userId is null
            if (userId != null) {
                User user = _db.Users.Single(u => u.UserId == userId);
                foreach (Mac m in user.Macs) {
                    if (m.Active && m.Mac1 == _viewData.ArpEntry.Mac) {
                        _viewData.ActivatedMac = true;
                    }
                }
            }
        }
    }
}