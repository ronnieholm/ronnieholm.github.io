﻿using System.Web.Mvc;

namespace Filosofparken.Controllers {
    public class HomeController : Controller {
        public void Index() {
            RenderView("Index");
        }
    }
}
