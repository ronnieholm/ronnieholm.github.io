sh /etc/routersetup/iptables/iptablessetup.sh
