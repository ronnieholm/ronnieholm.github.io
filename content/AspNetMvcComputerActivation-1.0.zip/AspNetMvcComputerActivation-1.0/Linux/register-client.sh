iptables -A APPROVED_MACS -m mac --mac-source $1 -j ACCEPT
iptables -t nat -A f_APPROVED_MACS -m mac --mac-source $1 -j ACCEPT
