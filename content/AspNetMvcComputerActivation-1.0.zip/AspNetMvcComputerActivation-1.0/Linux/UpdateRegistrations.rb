#!/usr/bin/ruby
require 'net/http'

VALIDATED_MACS_SERVER = "192.168.1.6"
VALIDATED_MACS_PORT = "80"
VALIDATED_MACS_PATH = "/User.mvc/ValidatedMacs"
VALIDATED_TOKEN = "#ValidatedToken#"

class UpdateRegistrations
  @current_validated_macs_hash = 0
  @last_validated_macs_hash = 0  

  def main
    begin
      ressource = Net::HTTP.new(VALIDATED_MACS_SERVER, VALIDATED_MACS_PORT)
      headers, data = ressource.get(VALIDATED_MACS_PATH)
      @current_validated_macs_hash = data.hash

      # if the IP is incorrect an exception is thrown. Similarly, if the port
      # is incorrect a timeout will cause an exception. However, an invalid
      # path causes the web server to respond with a page stating that "A
      # public action method named 'foo' could not be found on the controller".
      # Hence, we've introduced a validated token that must be present.
      if data.index(VALIDATED_TOKEN) == nil
        raise
      end
    rescue
      # better disable required registration 
      print "Disabling registration\n"
      `sh disable-registration.sh`      
      return
    end

    if @current_validated_macs_hash != @last_validated_macs_hash    
      print "Flushing rules\n"
      `sh enable-registration.sh`
      `iptables -t filter --flush APPROVED_MACS`
      `iptables -t nat --flush f_APPROVED_MACS`

      data.each do |line|
        # ignore validated token
        if not line.index(VALIDATED_TOKEN)
           mac = line.sub("\r\n", "")
           cmd = "sh register-client.sh " + mac
           print cmd + "\n"
           system(cmd)
        end
      end
      @last_validated_macs_hash = @current_validated_macs_hash         
    else
      print "No changes detected\n"
    end
  end
end

ur = UpdateRegistrations.new

while true
  ur.main
  sleep 60
end
