thttpd -C thttpd-registration.conf
