iptables -t filter --new-chain APPROVED_MACS
iptables -t filter --flush APPROVED_MACS
iptables -t nat --new-chain f_APPROVED_MACS
iptables -t nat --flush f_APPROVED_MACS

iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A FORWARD -p icmp -j ACCEPT
iptables -A FORWARD -i eth1 -p udp --dport 53 -j ACCEPT
iptables -A FORWARD -i eth1 -j APPROVED_MACS
iptables -t nat -A PREROUTING -i eth1 -j f_APPROVED_MACS
iptables -t nat -A PREROUTING -i eth1 -p tcp --dport 80 -j REDIRECT --to-ports 8081
