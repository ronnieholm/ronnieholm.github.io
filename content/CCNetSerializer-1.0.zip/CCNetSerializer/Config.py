# path to cvs.exe
cvs = "c:\\program files\\cvsnt\\cvs.exe"

# list of working copies of branches and their corresponding ccnet project names
watches = [ ("c:\\scc\\head", "head") ],
            ("c:\\scc\\another_branch", "another_branch") ]

# url of list of projects on ccnet server
CCNetDashboard = "http://ccnetserver/ccnet/default.aspx?_action_ViewFarmReport=true"
