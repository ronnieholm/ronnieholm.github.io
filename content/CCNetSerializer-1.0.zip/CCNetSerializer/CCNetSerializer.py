# Copyright (C) 2006 Ronnie Holm <r_holmes@yahoo.com>, Sirius IT (siriusit.com)
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place - Suite 330, Boston, MA 02111-1307, USA.

# Improvements: 
#	- Main should catch top level exceptions and log them before exiting.
#	- Add more charactor codes to Repository::Update()
#	- Rather than cheking if another ipy instance is running, check specifically for this
#	- Rewrite Run() to execute process and redirect output to temporary file
#	- Better error handling. Did a build break? Log result
#	- Autodetect changes to config.py and reload
#	- Terminate cvs.exe if not finished within x seconds to prevent hangs

# Changelog:
#
# 2006-12-07 Ronnie Holm
#	* Initial release

__version__ = "1.0"

from System import *
from System.Diagnostics import *
from System.Collections import *
from System.Net import *
from System.Text import *
from System.IO import *
import sys
import time
from Config import *

def Log(message):
	Debug.WriteLine(DateTime.Now.ToString() + ": " + message)

def Run(command, arguments = "", workingDirectory = "."):
    """Runs a external process, returning [ExitCode, stdout, stderr]."""
    p = Process()
    p.StartInfo.FileName = command
    p.StartInfo.Arguments = arguments
    p.StartInfo.WorkingDirectory = workingDirectory
    p.StartInfo.RedirectStandardOutput = True
    p.StartInfo.RedirectStandardError = True
    p.StartInfo.UseShellExecute = False
    p.Start()   
    
    # if you don't extract output, the process hangs! Why?
    outputWaiting = True
    while (outputWaiting):
		line = p.StandardError.ReadLine()
		if line != None:
			#print line
			Console.Write(".")
		else:
			outputWaiting = False
			Console.Write("\n")
    
    p.WaitForExit()
    return [p.ExitCode, p.StandardOutput.ReadToEnd(), p.StandardError.ReadToEnd()]

class Repository:
    """Thin wrapper around a cvs repository."""
    cvs = ""
    workingDirectory = ""

    def Update(self):
        """Update repository and return a list of updated files, since last update."""
        # cvs is crap. It sends stuff to stderr, although there is no error. Only lines
        # prefixed with a character code like "U" or "P" are actually send to stdout.
        result = Run(self.cvs, "update", self.workingDirectory)
        files = []
        lines = result[1].Split("\r\n".ToCharArray())

        for line in lines:
            if len(line) > 0:
                if ["U", "P"].Contains(line[0]):
                    files.Append(line[2:])
        return files
    
class CruiseControl:
	"""Thin wrapper around CruiseControl.Net."""
	dashboard = ""
	
	def ForceBuild(self, project):
		encoding = ASCIIEncoding()
		data = encoding.GetBytes("forcebuild=true&forceBuildProject=" + project + "&forceBuildServer=local")
		request = WebRequest.Create(self.dashboard)
		request.Method = "POST"
		request.ContentType = "application/x-www-form-urlencoded"
		request.ContentLength = data.Length
		stream = request.GetRequestStream()
		stream.Write(data, 0, data.Length)
		stream.Close() 		
		html = StreamReader(request.GetResponse().GetResponseStream(), encoding).ReadToEnd()
		
		if html.find("Build successfully forced for " + project) != -1:
			Log("Successfully initiated force build for: " + project)
			return True
		else:
			Log("Failed to initiate force build for: " + project)
			return False
			
	def IsBuilding(self):
		Log("Checking if CruiseControl is current building")
		encoding = ASCIIEncoding()
		request = WebRequest.Create(self.dashboard)
		html = StreamReader(request.GetResponse().GetResponseStream(), encoding).ReadToEnd()
		
		if html.find("Building") != -1:
			Log("CruiseControl build in progress")
			return True
		else:
			return False
			Log("No CruiseControl build in progress")
				 		 
if __name__ == "__main__":
	Debug.Listeners.Add(TextWriterTraceListener(Console.Out))
	Log("CCNetSerializer starting")

	if (len(Process().GetProcessesByName("ipy"))) > 1:
		Log("An instance of CCNetSerializer is already running. Exiting")
		sys.exit(0)

	q = Queue()

	for watch in watches:
		r = Repository()
		r.cvs = cvs
		r.workingDirectory = watch[0]
		Log("Checking for changes on: " + watch[0])
		changes = r.Update()

		if len(changes) > 0:
			Log("Enqueing: " + str(watch))
			q.Enqueue(watch)
		else:
			Log("No changes detected on: " + watch[0])
	
	while (q.Count > 0):
		c = CruiseControl()
		c.dashboard = CCNetDashboard
		watch = q.Dequeue()
		Log("Dequeing: " + str(watch))
		Log("Initiating force build on: " + watch[1])
		result = c.ForceBuild(watch[1])
		
		while True:
			if c.IsBuilding():
				Log("Going to sleep")
				time.sleep(20)
			else:
				Log("Waking up")
				break
		
	Log("CCNetSerializer ending")