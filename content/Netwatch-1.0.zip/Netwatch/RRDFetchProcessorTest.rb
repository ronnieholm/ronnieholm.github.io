=begin
Copyright (C) 2008 Ronnie Holm <r_holmes@yahoo.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA.
=end

require 'test/unit'
require 'RRDFetchProcessor'

class RRDFetchProcessorTest < Test::Unit::TestCase
  def test_parse
    r = RRDFetchProcessor.parse("                       in_bytes           out_bytes

1169382600: 1.7437605960e+04 6.6913576159e+02
1169382900: 1.7456587576e+04 6.6761325796e+02
1169383200: nan nan")

    assert_equal(3, r.length)
    assert_equal(1169382600, r[0][:timestamp])
    assert_equal(1.7437605960e+04, r[0][:in_bytes])
    assert_equal(6.6913576159e+02, r[0][:out_bytes])
    assert_equal(1.7456587576e+04, r[1][:in_bytes])
    assert_equal(6.6761325796e+02, r[1][:out_bytes])
    assert_equal(0.0, r[2][:in_bytes])
    assert_equal(0.0, r[2][:out_bytes])
  end

  def test_sum
    input = "                       in_bytes           out_bytes

1169382600: 1.7437605960e+04 6.6913576159e+02
1169382900: 1.7456587576e+04 6.6761325796e+02
1169383200: nan nan
1169383500: nan nan
1169383800: 3.7437605960e+04 4.6913576159e+02
1169384100: nan nan
1169384400: 3.2437605960e+04 4.9913576159e+02
1169384700: nan nan
"
    # match rrdtool fetch output intervals exactly
    assert_in_delta( (1.7437605960e+04 * 300),
                     RRDFetchProcessor.sum(1169382600, 1169382900, input)[:total_in_bytes],
                     1 ) 
    assert_in_delta( (6.6913576159e+02 * 300),
                      RRDFetchProcessor.sum(1169382600, 1169382900, input)[:total_out_bytes],
                      1 )
    
    # no direct match with rrdtool fetch output intervals
    # we actually count bytes for 200 seconds to many, but in practice the extra bytes
    # will make up a negligable part of the overall sum, so we just count them in
    assert_in_delta( ((1.7437605960e+04 * 300) + (1.7456587576e+04 * 300)),
                      RRDFetchProcessor.sum(1169382500, 1169383000, input)[:total_in_bytes],
                      1 )

    # including two nan's shouldn't affect the outcome
    assert_in_delta( ((1.7437605960e+04 * 300) + (1.7456587576e+04 * 300)),
                     RRDFetchProcessor.sum(1169382500, 1169383600, input)[:total_in_bytes],
                     1 );

    # having a combination of real data and nan's for in_bytes
    assert_in_delta( ((1.7437605960e+04 * 300) + (1.7456587576e+04 * 300) +
                      (3.7437605960e+04 * 300) + (3.2437605960e+04 * 300)),
                     RRDFetchProcessor.sum(1169382500, 1169384800, input)[:total_in_bytes],
                     1 )

    assert_in_delta( ((6.6913576159e+02 * 300) + (6.6761325796e+02 * 300) +
                      (4.6913576159e+02 * 300) + (4.9913576159e+02 * 300)),
                     RRDFetchProcessor.sum(1169382500, 1169384800, input)[:total_out_bytes],
                     1 )    
  end
end

