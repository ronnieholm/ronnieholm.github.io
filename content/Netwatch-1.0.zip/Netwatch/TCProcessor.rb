#!/usr/bin/ruby

=begin
Copyright (C) 2008 Ronnie Holm <r_holmes@yahoo.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA.
=end

class TCProcessor
  def TCProcessor.parse(input)
    computers = []

    results = input.scan(/class wrr (\w+:\w+) parent (\d+):\W*\(address: (\d+\.\d+\.\d+\.\d+)\)\W*\(total weight: (\S+)\)\W*\(current position: (\d+)\)\W*\(counters: (\d+) (\d+) : (\d+) (\d+)\)\W*Pars 1: \(weight (\S+)\) \(decr: (\S+)\) \(incr: (\S+)\) \(min: (\S+)\) \(max: (\S+)\)\W*Pars 2\
: \(weight (\S+)\) \(decr: (\S+)\) \(incr: (\S+)\) \(min: (\S+)\) \(max: (\S+)\)\W*\(bytes: (\S+)\) \(packets: (\S+)\)/)
  
    results.each do |r| 
      computer = { :child_class => r[0], :parent_class => r[1],
                   :ip_address => r[2], :total_weight => r[3].to_f,
                   :current_position => r[4].to_i, :counter_1 => r[5].to_i, 
                   :counter_2 => r[6].to_i, :counter_3 => r[7].to_i, 
                   :counter_4 => r[8].to_i, :pars_1_weight => r[9].to_f, 
                   :pars_1_decr => r[10], :pars_1_incr => r[11], 
                   :pars_1_min => r[12].to_f, :pars_1_max => r[13].to_f, 
                   :pars_2_weight => r[14].to_f, :pars_2_decr => r[15], 
                   :pars_2_incr => r[16], :pars_2_min => r[17].to_f, 
                   :pars_2_max => r[18].to_f, :bytes => r[19].to_i, 
                   :packets => r[20].to_i }
      computers.push(computer)
    end

    return computers
  end
end
