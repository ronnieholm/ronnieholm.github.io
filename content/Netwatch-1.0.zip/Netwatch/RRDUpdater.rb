#!/usr/bin/ruby

=begin
Copyright (C) 2008 Ronnie Holm <r_holmes@yahoo.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA.
=end

require 'find'
require 'IPProcessor'
require 'TCProcessor'
require 'Settings'
 
class RRDUpdater
  def main
    prepare_for_counter_reset if ARGV[0] == '--prepare-for-counter-reset'   

    output = TCProcessor.parse(`/usr/sbin/tc class show dev eth0`)# + OUTBOUND_INTERFACE))
    input = TCProcessor.parse(`/usr/sbin/tc class show dev eth1`)# + INBOUND_INTERFACE))
    ip_mac_mapping = IPProcessor.parse(`ip neigh`)

    output.each do |c1|
      in_bytes = -1
      out_bytes = c1[:bytes]
      mac_address = ip_mac_mapping[c1[:ip_address]]
      input.each { |c2| in_bytes = c2[:bytes] if c2[:ip_address] == c1[:ip_address] }
      rrd_update(mac_address, in_bytes, out_bytes) if not mac_address == nil and not in_bytes == -1 
    end
  end

  def rrd_update(mac_address, in_bytes, out_bytes)
    rrd_create(mac_address) if not File.exist?('databases/' + mac_address + '.rrd')

    if mac_address.length > 0
      rrd_update = 'rrdtool update ' + RRD_DATABASES + '/' + mac_address + '.rrd ' + 
                    Time.new.to_i.to_s + ':' + in_bytes.to_s + ':' + out_bytes.to_s
      puts rrd_update
      puts 'Command failed: ' + rrd_update if not system(rrd_update)
    end
  end

  def rrd_create(mac_address)
    rrd_create = RRD_DATABASE_TEMPLATE.gsub('MAC_PLACEHOLDER', mac_address)
    rrd_create = rrd_create.gsub('START_TIME', (Time.new.to_i - 1).to_s)
    puts rrd_create
    puts 'Command failed: ' + rrd_create if not system(rrd_create)
  end

  # before resetting a counter stored by rrd, such as when we reboot the computer or
  # reset tc, we must put a special 'unknown' value in each of the databases. This value
  # will cause rrd to use the next value as a new reference value. If we don't take this
  # approach, rrd will most likely attribute a large amount of bytes to each mac, that 
  # the mac never actually transferred (because of counter-wrap).
  def prepare_for_counter_reset
    Find.find(RRD_DATABASES, '.rrd') do |path|
      if not FileTest.directory?(path) and File.basename(path).length > 4
        rrd_update = 'rrdtool update ' + path + ' ' + Time.new.to_i.to_s + ':U:U'

        if not system(rrd_update)
          puts 'Command failed: ' + rrd_update
          exit
        end
      end
    end

    puts 'Ready to reset counters'
    exit
  end
end

p = RRDUpdater.new
p.main
