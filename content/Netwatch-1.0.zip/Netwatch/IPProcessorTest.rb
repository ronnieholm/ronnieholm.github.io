=begin
Copyright (C) 2008 Ronnie Holm <r_holmes@yahoo.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA.
=end

require 'test/unit'
require 'IPProcessor'

class IPProcessorTest < Test::Unit::TestCase
  def test_parse
    r = IPProcessor.parse("
192.168.2.19 dev eth1 lladdr 00:50:8d:68:50:75 REACHABLE
192.168.2.14 dev eth1 lladdr 00:11:d8:8f:0e:3b REACHABLE")

    assert_equal(2, r.length)
    assert_equal('00-50-8d-68-50-75', r['192.168.2.19'])
    assert_equal('00-11-d8-8f-0e-3b', r['192.168.2.14'])
  end
end

