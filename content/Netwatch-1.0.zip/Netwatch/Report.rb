=begin
Copyright (C) 2008 Ronnie Holm <r_holmes@yahoo.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA.
=end

require 'RRDFetchProcessor'
require 'IPProcessor'
require 'Settings'

class Report
  def main
    
  end

  def main1
    ip_mac_mapping = IPProcessor.parse(`/usr/sbin/ip neigh`)

    if ip_mac_mapping[ARGV[0]] == nil
      puts 'Unknown computer'
      exit
    end

    cmd = 'rrdtool fetch ' + RRD_DATABASES + '/' + ip_mac_mapping[ARGV[0]] + '.rrd AVERAGE --end N'
    cached_output = `#{cmd}`

    #puts "Current IP address: #{ARGV[0]}"

    RULES.each do |rule|
      stats = RRDFetchProcessor.sum(Time.new.to_i - rule[:duration], Time.new.to_i, cached_output)
      actual = 0
      direction = ''

      if rule[:limit] == 1
        actual = stats[:total_out_bytes]
        direction = 'upload'
      else
        actual = stats[:total_in_bytes]
        direction = 'download'
      end

      printf("Limit #{direction} " +
           "to #{(rule[:to] / GB)} GB " +
           "over #{rule[:duration] / HOUR} hours. Actual: %3.4f GB (%3.1f pct)\n", 
             actual / GB.to_f, actual / rule[:to].to_f * 100)
    end
  end
end

r = Report.new
r.main1
