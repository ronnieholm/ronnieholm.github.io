while [ true ]; do
  cd /root/ronnie/netwatch
  time ruby RRDUpdater.rb
  time ruby Autoblocker.rb
  sleep 60
done

