=begin
Copyright (C) 2008 Ronnie Holm <r_holmes@yahoo.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA.
=end

require 'Constants'

INBOUND_INTERFACE = 'eth1'
OUTBOUND_INTERFACE = 'eth0'
RRD_DATABASES = 'databases'
RRD_DATABASE_TEMPLATE = 'rrdtool create databases/MAC_PLACEHOLDER.rrd ' +
          '--start START_TIME ' +
          'DS:in_bytes:COUNTER:120:0:720000000 ' +
          'DS:out_bytes:COUNTER:120:0:720000000 ' +
          'RRA:AVERAGE:0.5:1:1440 ' +
          'RRA:AVERAGE:0.5:120:12 ' +
          'RRA:AVERAGE:0.5:1140:90'

# todo: rename limit to direction and to to max or limit_to
RULES = [ { :limit => UPLOAD, :duration => 4 * HOUR, :to => 1 * GB },
          { :limit => DOWNLOAD, :duration => 4 * HOUR, :to => 5 * GB },
          { :limit => UPLOAD, :duration => 7 * DAY, :to => 15 * GB },
          { :limit => DOWNLOAD, :duration => 7 * DAY, :to => 30 * GB} ]

# { :direction => UPLOAD, :duration => 4 * HOUR, limit => 1 * GB }
