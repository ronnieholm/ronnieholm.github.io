#!/usr/bin/ruby

=begin
Copyright (C) 2008 Ronnie Holm <r_holmes@yahoo.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA.
=end

require 'test/unit'
require 'TCProcessor'

class TCProcessorTest < Test::Unit::TestCase
  def test_parse
    r = TCProcessor.parse("class wrr 8001:1fb parent 8001:
  (address: 192.168.1.231)
  (total weight: 0.872749) (current position: 4) (counters: 1 2 : 3 4)
  Pars 1: (weight 0.872749) (decr: 1e-10) (incr: 7.5e-11) (min: 0.1) (max: 1)
  Pars 2: (weight 1) (decr: 0) (incr: 0) (min: 1) (max: 1)
  (bytes: 4546184) (packets: 55373)")
    c = r[0]

    assert_equal(1, r.length)
    assert_equal('8001:1fb', c[:child_class])
    assert_equal('8001', c[:parent_class])
    assert_equal('192.168.1.231', c[:ip_address])
    assert_equal(0.872749, c[:total_weight])
    assert_equal(4, c[:current_position])
    assert_equal(1, c[:counter_1])
    assert_equal(2, c[:counter_2])
    assert_equal(3, c[:counter_3])
    assert_equal(4, c[:counter_4])
    assert_equal(0.872749, c[:pars_1_weight])
    assert_equal('1e-10', c[:pars_1_decr])
    assert_equal('7.5e-11', c[:pars_1_incr])
    assert_equal(0.1, c[:pars_1_min])
    assert_equal(1, c[:pars_1_max])
    assert_equal(1, c[:pars_2_weight])
    assert_equal("0", c[:pars_2_decr])
    assert_equal("0", c[:pars_2_incr])
    assert_equal(1, c[:pars_2_min])
    assert_equal(1, c[:pars_2_max])
    assert_equal(4546184, c[:bytes])
    assert_equal(55373, c[:packets])
  end
end
