=begin
Copyright (C) 2008 Ronnie Holm <r_holmes@yahoo.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA.
=end

require 'Settings'

class RRDFetchProcessor
  def RRDFetchProcessor.parse(input)
    measurements = []
    results = input.scan(/(\d+): (\S+) (\S+)/)
    
    results.each do |r|
      measure = { :timestamp => r[0].to_i, :in_bytes => r[1].to_f, :out_bytes => r[2].to_f}
      measurements.push(measure)
    end

    return measurements
  end

  def RRDFetchProcessor.sum(from_time, to_time, input)
    m = RRDFetchProcessor.parse(input)
    total_in_bytes = 0
    total_out_bytes = 0

    # assume m.length >= 2 and it always keeps the same (throw exception if not true)
    time_delta = m[1][:timestamp] - m[0][:timestamp]

    for i in (0..m.length - 1)
      if m[i][:timestamp] >= from_time and m[i][:timestamp] < to_time and i
        total_in_bytes += m[i][:in_bytes] * time_delta
        total_out_bytes += m[i][:out_bytes] * time_delta      
      end
    end 

    return { :total_in_bytes => total_in_bytes.to_i, :total_out_bytes => total_out_bytes.to_i }
  end

  def RRDFetchProcessor.multi_sum(mac_address, time_deltas)
    cmd = 'rrdtool first ' + RRD_DATABASES + '/' + mac_address + '.rrd'
    earliest_valid_rrd_timestamp = `#{cmd}`
    earliest_rule_timestamp_delta = 0

    time_deltas.each { |delta| earliest_rule_timestamp_delta = delta if earliest_rule_timestamp_delta < delta }
    start_timestamp = Time.new.to_i - earliest_rule_timestamp_delta

    if start_timestamp.to_i < earliest_valid_rrd_timestamp.to_i
      start_timestamp = earliest_valid_rrd_timestamp.to_i
    end

    cmd = 'rrdtool fetch ' + RRD_DATABASES + '/' + mac_address + '.rrd AVERAGE --start ' + start_timestamp.to_s + ' --end ' + Time.new.to_i.to_s
    cached_output = `#{cmd}`
    results = []

    time_deltas.each do |delta|
      stats = RRDFetchProcessor.sum(Time.new.to_i - delta, Time.new.to_i, cached_output)
      results.push({ :total_in_bytes => stats[:total_in_bytes], :total_out_bytes => stats[:total_out_bytes]})
    end

    return results
  end
end
