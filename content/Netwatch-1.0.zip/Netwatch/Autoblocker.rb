#!/usr/bin/ruby

=begin
Copyright (C) 2008 Ronnie Holm <r_holmes@yahoo.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA.
=end

require 'find'
require 'RRDFetchProcessor'
require 'Settings'

class Autoblocker
  attr_writer :on_overlimit_event

  def initialize
    @on_overlimit_event = []
  end

  def main
    #@on_overlimit_event.push(lambda { overlimit })
    #@on_overlimit_event.each { |callback| callback('abc', 'rule', 123) }

    Find.find(RRD_DATABASES, '.rrd') do |path|
      if not FileTest.directory?(path) and File.basename(path).length > 4
        # todo: optimize by computing the maximum amount of time we have to go back from the rules
        # default for start i N - 1 day. We'll have to correct for this in a dynamic way (for now we hardcode 1 week)
        # use {} notation in strings
        cmd  = 'rrdtool fetch ' + path + ' AVERAGE --end N' 
        cached_output = `#{cmd}`
        mac_address = File.basename(path, '.rrd')

        # use RRDFetchProcessor.multi_sum here

        RULES.each do |rule|
          stats = RRDFetchProcessor.sum(Time.new.to_i - rule[:duration], Time.new.to_i, cached_output)
          overlimit(mac_address, rule, stats[:total_out_bytes]) if rule[:limit] == UPLOAD and stats[:total_out_bytes] > rule[:to]
          overlimit(mac_address, rule, stats[:total_in_bytes]) if rule[:limit] == DOWNLOAD and stats[:total_in_bytes] > rule[:to]
        end
      end
    end
  end

  def overlimit(mac_address, rule, actual_bytes)
    puts "# netwatch: #{mac_address} #{actual_bytes}"
    #puts 'iptables -A BLOCKED_CLIENTS -i $LAN_NIC -m mac --mac-source ' + mac_address.gsub('-', ':') + ' -j DROP'

    cmd = 'python /etc/routersetup/blocking/blockclient.py ' + mac_address.gsub('-', ':') + ' 3600'
    puts 'Command failed: ' + cmd if not system(cmd)

    #puts 'iptables -t nat -A PREROUTING -i $LAN_NIC -m mac --mac-source ' + mac_address.gsub('-', ':') + ' -j INFO'
    #puts 'iptables -A FORWARD -i $LAN_NIC -m mac --mac-source ' + mac_address.gsub('-', ':') + ' -j BLOCKED_CLIENT'
  end
end

p = Autoblocker.new
p.main
