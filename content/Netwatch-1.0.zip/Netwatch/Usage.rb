=begin
Copyright (C) 2008 Ronnie Holm <r_holmes@yahoo.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA.
=end

require 'RRDFetchProcessor'
require 'IPProcessor'
require 'Settings'
require 'Constants'
require 'find'

class Usage
  def main
    if ARGV[0] == '--all'
      display_report
    end

    if ARGV[0] == '--ip'
      ip_mac_mapping = IPProcessor.parse(`/usr/sbin/ip neigh`)

      if ip_mac_mapping[ARGV[1]] == nil
        puts 'Unknown computer'
        exit
      end

      RULES.each do |rule|
        stats = RRDFetchProcessor.multi_sum(ip_mac_mapping[ARGV[1]], [rule[:duration]])
        direction = ''

        if rule[:limit] == 1
          actual = stats[0][:total_out_bytes]
          direction = 'upload'
        else
          actual = stats[0][:total_in_bytes]
          direction = 'download'
        end

        printf("Rule: Limit #{direction} " +
               "to #{(rule[:to] / GB)} GB " +
               "over #{rule[:duration] / HOUR} hours. Actual: %3.3f GB (%3.1f pct)\n", 
               actual / GB.to_f, actual / rule[:to].to_f * 100)
      end
    end
  end

  def display_report
    # collect all information beforehand and display the list four times, sorted on each column
    # chance resolution of rrdtool fetch to speed up the report generation process
    # have a shared method return a list of databases

    deltas = []
    RULES.each { |rule| deltas.push(rule[:duration]) }
    puts "MAC\t\t\t#1 UL\t#1 DL\t#2 UL\t#2 DL"

    Find.find(RRD_DATABASES, '.rrd') do |path|
      if not FileTest.directory?(path) and File.basename(path).length > 4
        mac_address = File.basename(path, '.rrd')
        sums = RRDFetchProcessor.multi_sum(mac_address, deltas)
        printf("#{mac_address}\t%3.3f\t%3.3f\t%3.3f\t%3.3f\n", sums[0][:total_out_bytes] / GB.to_f, 
                                                               sums[0][:total_in_bytes] / GB.to_f, 
                                                               sums[1][:total_out_bytes] / GB.to_f, 
                                                               sums[1][:total_in_bytes] / GB.to_f)
      end
    end
  end
end

#puts RRDFetchProcessor.multi_sum('00-11-43-71-2e-15', [14400, 604800])

u = Usage.new
u.main
