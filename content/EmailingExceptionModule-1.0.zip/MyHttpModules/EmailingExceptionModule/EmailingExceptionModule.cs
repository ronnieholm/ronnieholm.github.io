﻿/*
 * Software License Agreement (BSD License)
 * 
 * Copyright (c) 2008, Ronnie Holm <r_holmes@yahoo.com>, http://www.bugfree.dk.
 * All rights reserved.
 * 
 * Redistribution and use of this software in source and binary forms, with or without modification, are
 * permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * The name of the copyright holder may not be used to endorse or promote 
 *       products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net.Mail;
using System.Reflection;
using System.Web;

namespace Holm.AspNet {
    public class EmailingExceptionModule : IHttpModule {
        private const string HEADING = "HEADING";

        private readonly IList<Dictionary<string, string>> _dumpContainers = new List<Dictionary<string, string>>();
        private HttpApplication _application;
        private Exception _exception;

        public void Init(HttpApplication context) {
            _application = context;
            _application.Error += OnUnhaltedException;
        }

        public void Dispose() { }

        private string GetResource(string resourceName) {
            Assembly a = Assembly.GetExecutingAssembly();
            using (TextReader tr = new StreamReader(a.GetManifestResourceStream(resourceName)))
                return tr.ReadToEnd();
        }

        private void OnUnhaltedException(object sender, EventArgs e) {
            try {
                _exception = _application.Server.GetLastError().InnerException;
                CollectDumpContainers();
                var m =
                    new MailMessage(
                        new MailAddress(ConfigurationManager.AppSettings["EmailingExceptionModule_SenderAddress"]),
                        new MailAddress(ConfigurationManager.AppSettings["EmailingExceptionModule_ReceiverAddress"]));
                m.Subject = ConfigurationManager.AppSettings["EmailingExceptionModule_SubjectPrefix"] +
                            _exception.GetType();
                m.Body = ComposeEmail();
                m.IsBodyHtml = true;

                var smtpClient = new SmtpClient();
                smtpClient.Host = ConfigurationManager.AppSettings["EmailingExceptionModule_SmtpServer"];
                smtpClient.Send(m);
            }
#pragma warning disable 168
            // although ex isn't used, it's nice to have access to when debugging
            catch (Exception ex) {
#pragma warning restore 168
                // we're out of options
            }
        }

        private void CollectDumpContainers() {
            var s = new Dictionary<string, string>();
            s[HEADING] = "Summary";
            s["Remote address"] = _application.Request.ServerVariables["REMOTE_ADDR"];
            s["User agent"] = _application.Request.ServerVariables["HTTP_USER_AGENT"];
            s["Absolute url"] = _application.Request.Url.AbsoluteUri;
            s["Time"] = DateTime.Now.ToString();
            s["Exception"] = _exception.ToString();
            _dumpContainers.Add(s);

            var sv = new Dictionary<string, string>();
            sv[HEADING] = "Server variables";
            foreach (string k in _application.Request.ServerVariables.Keys)
                sv[k] = _application.Request.ServerVariables[k];
            _dumpContainers.Add(sv);
        }

        private string ComposeEmail() {
            string css = GetResource("EmailingExceptionModule.Email.css");
            string tableTemplate = GetResource("EmailingExceptionModule.TableTemplate.htm");
            string rowTemplate = GetResource("EmailingExceptionModule.RowTemplate.htm");
            string body = string.Format(
                @"<style type=""text/css"">
                        <!--
                            {0}
                        -->
                    </style>",
                css);

            foreach (var t in _dumpContainers) {
                string rows = "";
                foreach (var kvp in t) {
                    if (kvp.Key != HEADING)
                        rows += rowTemplate.Replace("KEY", kvp.Key).Replace("VALUE", kvp.Value);
                }

                body += tableTemplate.Replace("ROW_TEMPLATE", rows).Replace("HEADING", t[HEADING]);
                body += "<br />";
            }

            return body;
        }
    }
}